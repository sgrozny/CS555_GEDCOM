/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cs555_ged;

/**
 *
 * @author sgrozny
 */
public class Testing {
    public static void Test_Sprint1(IndvidualStruct.individual indArr[], FamilyStruct.family famArr[], int Itotal, int Ftotal, int Ctotal){
            StasSprint1.TwoIdenticalIndviduals(indArr,Itotal);
    }
}
