/*
 * "I pledge my honor that I have abided by the Stevens Honor System"
 * Stas Grozny
 */
package cs555_ged;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
public class CS555_GED {
    static String TAGS[] = new String [16];
    
    public static void main(String[] args) {
        
        String  Ged_Filename = "C:/Users/Class2016/Downloads/My-Family-27-Jan-2015.ged";
         initTagArray(); //Loads in valid tags      
        try {
                //Read file
		File file = new File(Ged_Filename);
		FileReader fileReader = new FileReader(file);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		StringBuffer stringBuffer = new StringBuffer();
		String line;
                //While there are lines then call the print method.
                
		while ((line = bufferedReader.readLine()) != null) {
                        Print_Ged_Lines(line);
		}
                
		fileReader.close(); //close file reader
		} 
        //catches any errors
                catch (IOException e) {
			e.printStackTrace();
		}
    }
    private static void Print_Ged_Lines(String inputline){
        /*Private Method that will print 3 lines 
        * Precondition: Given a line from a Gedcom file
        * Postcondition: Print the orignal line, print level-number, tag
        */
        System.out.println(inputline);//Print original line
        int index;  //index of first " "
        int i;// used in for loop
        String tag;//finds tag
        boolean valid=false;    // checks if tag is valid (default is false)
        index= inputline.indexOf(" ");  // find index of first space
        System.out.println(inputline.substring(0,index));   //print the level number
        int index2; // index of second " "
        index2= inputline.indexOf(" ", index+1); 
        if (index2==-1) {//if there is no second space just a tag followed by nothing
            tag=inputline.substring(index+1);//then the end of tag is last character
        }
        else{//else the tag is between the 2 spaces
           tag=inputline.substring(index+1,index2);
        } 
        //Compare obtained tag to list of predefined tags
        for (i=0;i<16;i++){      
            if (tag.equals(TAGS[i])){
                valid=true; //if its found then its a valid tag and no need to keep looking
                break;
            }
        }
        if (valid) {//if tag is valid then print it
            System.out.println(tag);
        }
        else {//else print invalid tag
            System.out.println("Invalid tag");
        }
        System.out.println("---------------------------------------");//prints a break so it is easier to read
        
    }
     public static void initTagArray(){
         //intializes the array of tags
         //Preconditions: None
         //Postconditions; The TAGS array is populated with all the valid tags
         TAGS[0]="NOTE";
         TAGS[1]="INDI";
         TAGS[2]="NAME";
         TAGS[3]="SEX";
         TAGS[4]="BIRT";
         TAGS[5]="DEAT";
         TAGS[6]="FAMC";
         TAGS[7]="FAMS";
         TAGS[8]="FAM";
         TAGS[9]="MARR";
         TAGS[10]="HUSB";
         TAGS[11]="WIFE";
         TAGS[12]="CHIL";
         TAGS[13]="DIV";
         TAGS[14]="DATE";
         TAGS[15]="TRLR";
                 
     }       
}
